<template>
  <div>
    <div>
<router-view :to="{name: 'Articulo'}"></router-view>
</div>
    </div>
</template>

