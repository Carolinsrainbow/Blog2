  <template>
<div>
        <header
      class="masthead"
      style="background-image: url('/assets/img/chevrolet-blazer.jpg');"
    >
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-lg-8 mx-auto">
            <div class="post-heading">
              <h1>
                <strong>Chevrolet presenta la totalmente nueva Blazer</strong>
              </h1>
              <h2 class="subheading">
                <strong>Llega como la primera SUV deportiva de la marca</strong>
              </h2>
            </div>
          </div>
        </div>
      </div>
    </header>
    <div>
    <h1>Soy la vista de Administrador</h1>
         <router-link :to="{name: 'AdminSimple'}">Simple</router-link>
         <router-link :to="{name: 'AdminAvanzado'}">Avanzado</router-link>
    <router-view></router-view>
    <footer>
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-lg-8 mx-auto">
                <ul class="list-inline text-center">
                    <li class="list-inline-item"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-twitter fa-stack-1x fa-inverse"></i></span></li>
                    <li class="list-inline-item"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-facebook fa-stack-1x fa-inverse"></i></span></li>
                    <li class="list-inline-item"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x"></i><i class="fa fa-github fa-stack-1x fa-inverse"></i></span></li>
                </ul>
                <p class="text-muted copyright">Copyright&nbsp;©&nbsp;V8 - 2018</p>
            </div>
        </div>
    </div>
</footer>
    </div>
</div>
</template>