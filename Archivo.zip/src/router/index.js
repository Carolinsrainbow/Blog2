import Vue from 'vue'
import VueRouter from 'vue-router'
import Portada from '../views/Portada.vue'
import Contacto from '../views/Contacto.vue'
import SobreMi from '../views/SobreMi.vue'
import Post from '../views/Post.vue'
import NotFound from '../views/NotFound.vue'
import Articulo from '../components/Articulo.vue'
import Administrador from '../views/Administrador.vue'
import AdminSimple from '../components/AdminSimple.vue'
import AdminAvanzado from '../components/AdminAvanzado.vue'
import NotFoundAdmin from '../components/NotFoundAdmin.vue'


Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name: 'Portada',
    component: Portada
  },
  {
    path: '/Contacto',
    name: 'Contacto',
    component: Contacto,
    alias: ["/contactame"]
  },
  {
    path: '/SobreMi',
    name: 'SobreMi',
    component: SobreMi,
    alias: ["/acerca"]
  },
  {
    path: '/Post/', 
    name: 'Post',
    component: Post,
    children: [
      {
        path: ':articulo',
        name: 'Articulo',
        component: Articulo,
      }
    ], 
  },
  {
    path: '/administrador/', 
    name: 'Administrador',
    component: Administrador,
    children: [
      {
        path: 'simple',
        name: 'AdminSimple',
        component: AdminSimple,
      },
      {
        path: 'avanzado',
        name: 'AdminAvanzado',
        component: AdminAvanzado,
      },
      {
        path: '*',
        name: 'NotFoundAdmin',
        component: NotFoundAdmin,
      },
    ], 
  },
  {
    path: '*',
    name: 'NotFound',
    component: NotFound
  },
  {
    path: "/portada",
    redirect: { name: "Portada" }
  },
  {
    path: "/home",
    redirect: { name: "Portada" }
  },
  {
    path: "/inicio",
    redirect: { name: "Portada" }
  }
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
