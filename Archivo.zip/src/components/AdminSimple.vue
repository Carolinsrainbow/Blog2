<template>
    <div>
         <h1>Bienvenido a la página de Administración”</h1>
        </div>
</template>