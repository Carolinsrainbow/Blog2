<template>
    <div>
<h1>Esta página de administración está en construcción.
Intente como administrador simple</h1>
<router-view :to="{name: 'AdminSimple'}"></router-view>
<router-view :to="{name: 'AdminAvanzado'}"></router-view>
        </div>
</template>