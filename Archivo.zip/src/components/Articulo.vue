<template>
  <div>
    <header
      class="masthead"
      style="background-image: url('/assets/img/chevrolet-blazer.jpg');"
    >
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-lg-8 mx-auto">
            <div class="post-heading">
              <h1>
                <strong>Chevrolet presenta la totalmente nueva Blazer</strong>
              </h1>
              <h2 class="subheading">
                <strong>Llega como la primera SUV deportiva de la marca</strong>
              </h2>
            </div>
          </div>
        </div>
      </div>
    </header>
    <article>
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-lg-8 mx-auto">
            <p>
              La marca del corbatín ha estado muy activa de novedades este 2019,
              y acaba de presentar en Chile su primer SUV deportivo, que recobra
              un conocido nombre de la marca, la Blazer, que ahora llega con
              mucha más cercanía al diseño y concepto del Camaro que el del todo
              terreno rudo que fue hace años atrás.
            </p>
            <p>
              Aterriza en nuestro país en dos versiones, ambas muy equipadas y
              que solamente varían en su look, o más deportivo o más
              elegante.&nbsp;La primera es la RS, que ofrece detalles deportivos
              en negro brillante, incluyendo el tradicional corbatín, mientras
              que la versión Premier ofrece un look más elegante, con muchos
              detalles cromados y que recuerda más a otros modelos de la marca.
              Ambas se ofrecen a un precio de lanzamiento de $29.990.000,
              incluyendo bonos de lanzamiento y de financiamiento (precio sin
              bonos es $31.990.000).
            </p>
            <h2 class="section-heading"><strong>DISEÑO DEPORTIVO</strong></h2>
            <p>
              Lo primero que se aprecia es su diseño exterior, que aunque en un
              tamaño no menor de casi 4.9 metros, se ve bastante atractivo y
              elegante, con un frontal muy afilado, con una boca muy grande,
              luces diurnas LED superiores y principales abajo HID con
              tecnología Intellibeam. El lateral se ve muy estilizado, con sus
              llantas de 21 pulgadas, y una parte trasera que recuerda a otros
              modelos emblemáticos del segmento, como la Nissan Murano o Lexus
              RX. La trasera ofrece un portalón con una buena caída, doble
              salida de escape y hermosas luces LED con un mini logo de la
              marca.
            </p>
            <p>
              El interior es donde más se asemeja a su hermano deportivo Camaro,
              con un tablero deportivo y realmente muy equipado, con detalles
              como las salidas de aire circulares, pantalla central en tablero
              de instrumentos,&nbsp;volante deportivo, sistema multimedia con
              MyLink con Android Auto y Apple Carplay, cargador inhalámbrico,
              mientras que según su versión, los asientos están tapizados en
              cuero negro perforado en la versión Premier mientras que en la
              versión RS el tapiz con inserciones de micro fibra gamuzada y
              detalles rojos en todo el interior.
            </p>
            <blockquote class="blockquote">
              <p class="mb-0"></p>
            </blockquote>
            <p>
              Su equipamiento de seguridad es realmente completo, ofreciendo
              desde los siete airbags, control de estabilidad, frenos de disco
              en las cuatro ruedas, control crucero adaptativo, alerta de cambio
              de carril, alerta de tráfico cruzado, alerta de colisión frontal,
              asistente de frenado a bajas velocidades, alerta en el asiento del
              conductor, asistente activo de estacionamiento y cámara de 360°.
            </p>
            <p>
              El motor de ambas versiones es un V6 de 3.6 litros que entrega una
              potencia de 308 Hp y 365 Nm, que se acopla a una caja automática
              de nueve velocidades, transmitiendo al suelo esta potencia gracias
              a un sistema AWD con diferentes modos de manejo. Para mejorar algo
              la eficiencia, integra un sistema de encendido y apagado de motor
              automático Start&amp;Stop.
            </p>
            <a href="#"></a>
          </div>
        </div>
      </div>
    </article>
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-lg-8 mx-auto">
            <ul class="list-inline text-center">
              <li class="list-inline-item">
                <span class="fa-stack fa-lg"
                  ><i class="fa fa-circle fa-stack-2x"></i
                  ><i class="fa fa-twitter fa-stack-1x fa-inverse"></i
                ></span>
              </li>
              <li class="list-inline-item">
                <span class="fa-stack fa-lg"
                  ><i class="fa fa-circle fa-stack-2x"></i
                  ><i class="fa fa-facebook fa-stack-1x fa-inverse"></i
                ></span>
              </li>
              <li class="list-inline-item">
                <span class="fa-stack fa-lg"
                  ><i class="fa fa-circle fa-stack-2x"></i
                  ><i class="fa fa-github fa-stack-1x fa-inverse"></i
                ></span>
              </li>
            </ul>
            <p class="text-muted copyright">Copyright&nbsp;©&nbsp;V8 - 2018</p>
          </div>
        </div>
      </div>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'Articulo'
};
</script>

<style lang="scss" scoped></style>